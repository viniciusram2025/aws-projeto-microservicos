export const ACCEPTED = "ACCEPTED";
export const PENDING = "PENDING";
export const REJECTED = "REJECTED";